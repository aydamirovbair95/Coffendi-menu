const state={items:[],filtered:[]};

async function loadMenu(){
  const res=await fetch('menu.json');
  state.items=await res.json();
  const catSet=new Set(state.items.map(i=>i.category));
  const sel=document.getElementById('categoryFilter');
  [...catSet].sort().forEach(c=>{
    const opt=document.createElement('option');
    opt.value=c; opt.textContent=c; sel.appendChild(opt);
  });
  applyFilters();
}

function applyFilters(){
  const q=document.getElementById('search').value.trim().toLowerCase();
  const cat=document.getElementById('categoryFilter').value;
  state.filtered=state.items.filter(it=>{
    if(q && !it.name.toLowerCase().includes(q)) return false;
    if(cat && it.category!==cat) return false;
    return true;
  });
  render();
}

function render(){
  const root=document.getElementById('menuContainer');
  root.innerHTML='';
  if(!state.filtered.length){
    const div=document.createElement('div');
    div.className='empty'; div.textContent='Ничего не найдено';
    root.appendChild(div); return;
  }
  state.filtered.forEach(it=>{
    const card=document.createElement('div');
    card.className='card';
    const h3=document.createElement('h3'); h3.textContent=it.name;
    const price=document.createElement('div'); price.className='price'; price.textContent=it.price+' '+it.currency;
    card.appendChild(h3); card.appendChild(price);
    root.appendChild(card);
  });
}

window.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('search').addEventListener('input',applyFilters);
  document.getElementById('categoryFilter').addEventListener('change',applyFilters);
  loadMenu();
});
